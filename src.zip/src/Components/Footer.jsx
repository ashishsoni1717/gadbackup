import React from 'react';

function Footer () {
    return ( 
        <div>
             <div className="footer-top-wrapper">
    <div className="container footer-top-container">
      <ul>
        <li><a href="inner.html">Feedback</a></li>
        <li><a href="inner.html">Website Policies </a></li>
        <li><a href="inner.html">Contact Us</a></li>
        <li><a href="inner.html">Web Information Manager </a></li>
        <li><a href="inner.html">FAQ’s</a></li>
        <li><a href="inner.html">Disclaimer</a></li>
        <li><a href="inner.html">Help</a></li>
        <li><a href="inner.html">Terms & Conditions</a></li>
      </ul>
    </div>
  </div>
            <div className="footer-bottom-wrapper">
    <div className="container footer-bottom-container">
      <div className="footer-content clearfix">
        <div className="copyright-content"> 
            Website Content Managed by <strong>Department Name, Ministry Name, <a target="_blank"  rel="noreferrer" title="GoI, External Link that opens in a new window" href="https://www.india.gov.in/"><strong>Government of India</strong></a></strong> 
            <span>Designed, Developed and Hosted by <a target="_blank"  rel="noreferrer" title="NIC, External Link that opens in a new window" href="https://www.nic.in/"><strong>National Informatics Centre</strong></a><strong> (NIC)</strong></span>
            <span className="last-updated">Last Updated: <span id="lastupdated"></span></span>
        </div>

      </div>
    </div>
  </div> 
</div>
     );
}

export default Footer ;




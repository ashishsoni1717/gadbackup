import React from 'react';

function Notice() {
    return ( 
        <div>
             <div id="feedTab">
            <ul className="resp-tabs-list feedTab_1 clearfix">
                <li> <a href="inner.html"><i className="fa fa-refresh"></i> Latest Updates</a></li>
                <li> <a href="inner.html"><i className="fa fa-newspaper-o"></i> Press Releases</a></li>
                <li> <a href="inner.html"><i className="fa fa-star"></i> Important Activities</a></li>
                <li> <a href="inner.html"><i className="fa fa-clock-o"></i> Forthcoming/Recent Events</a></li>
                
            </ul>
            <div className="resp-tabs-container feedTab_1">
                <div>
                      <ul className="list">
                      	<li>Information about Latest Update 1 goes here</li>
                        <li>Information about Latest Update 2 goes here</li>
                        <li>Information about Latest Update 3 goes here</li>
                        <li>Information about Latest Update 4 goes here</li>
                        <li>Information about Latest Update 5 goes here</li>
                        <li>Information about Latest Update 6 goes here</li>
                        <li>Information about Latest Update 7 goes here</li>
                        <li>Information about Latest Update 8 goes here</li>
                        <li>Information about Latest Update 9 goes here</li>
                      </ul>    
                      
                      <a className="read-more" href="#" >Read more</a> 
                </div>
               
                <div>
                      <ul className="list">
                      	<li>Information about Press Release 1 goes here (dd mm yyyy, pdf, size)</li>
                        <li>Information about Press Release 2 goes here (dd mm yyyy, pdf, size)</li>
                        <li>Information about Press Release 3 goes here (dd mm yyyy, pdf, size)</li>
                        <li>Information about Press Release 4 goes here (dd mm yyyy, pdf, size)</li>
                        <li>Information about Press Release 5 goes here (dd mm yyyy, pdf, size)</li>
                        <li>Information about Press Release 6 goes here (dd mm yyyy, pdf, size)</li>
                        <li>Information about Press Release 7 goes here (dd mm yyyy, pdf, size)</li>
                        <li>Information about Press Release 8 goes here (dd mm yyyy, pdf, size)</li>
                        <li>Information about Press Release 9 goes here (dd mm yyyy, pdf, size)</li>
                          
                      </ul>    
                      
                      <a className="read-more" href="#">Read more</a> 
                </div>
                
                
                <div>
                     <ul className="list">
                        <li>Information about Important Activity 1 goes here</li>
                        <li>Information about Important Activity 2 goes here</li>
                        <li>Information about Important Activity 3 goes here</li>
                        <li>Information about Important Activity 4 goes here</li>
                        <li>Information about Important Activity 5 goes here</li>
                        <li>Information about Important Activity 6 goes here</li>
                        <li>Information about Important Activity 7 goes here</li>
                        <li>Information about Important Activity 8 goes here</li>
                        <li>Information about Important Activity 9 goes here</li>
                          
                      </ul>    
                      
                      <a className="read-more" href="inner.html">Read more</a> 
                      
                </div>
                
                <div>
                    <ul className="list">
                        <li>Information about Forthcoming Event 1 goes here</li>
                        <li>Information about Forthcoming Event 2 goes here</li>
                        <li>Information about Forthcoming Event 3 goes here</li>
                        <li>Information about Forthcoming Event 4 goes here</li>
                        <li>Information about Forthcoming Event 5 goes here</li>
                        <li>Information about Forthcoming Event 6 goes here</li>
                        <li>Information about Forthcoming Event 7 goes here</li>
                        <li>Information about Forthcoming Event 8 goes here</li>
                        <li>Information about Forthcoming Event 9 goes here</li>
                          
                      </ul>    
                      
                      <a className="read-more" href="inner.html">Read more</a> 
                      
                     
                </div>
                
               
                
            </div>
        </div>
        
      </div>
    
     );
}

export default Notice;
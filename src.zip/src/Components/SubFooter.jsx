import React from 'react';

function SubFooter() {
    return ( 
        <div>
           <div className="wrapper carousel-wrapper">
  <div className="container carousel-container">
    <div id="flexCarousel" className="flexslider carousel">
      <ul className="slides">
        <li><a target="_blank"  rel="noreferrer" href="https://data.gov.in/" title="Data portal, External Link that opens in a new window" ><img src="assets/images/carousel/data-gov.png" alt="Data gov website link"/></a></li>
        <li><a target="_blank"  rel="noreferrer" href="http://india.gov.in/" title="National Portal of India, External Link that opens in a new window"><img src="assets/images/carousel/india-gov.png" alt="India gov website link"/></a></li>
        <li><a target="_blank"  rel="noreferrer" href="https://www.incredibleindia.org" title="Incredible India, External Link that opens in a new window"><img src="assets/images/incredible-india.png" alt="Incredible India website link"/></a></li>
        <li><a target="_blank"  rel="noreferrer" href="https://digitalindia.gov.in/" title="Digital India, External Link that opens in a new window"><img src="assets/images/carousel/digital-india.png" alt="Digital India website link"/></a></li>
        <li><a target="_blank"  rel="noreferrer" href="https://pmnrf.gov.in/" title="Prime Minister's National Relief Fund, External Link that opens in a new window"><img src="assets/images/carousel/ganhri.png" alt="PMNRF website link"/></a></li>
        <li><a target="_blank"  rel="noreferrer" href="http://www.makeinindia.com/" title="Make In India, External Link that opens in a new window"> <img src="assets/images/carousel/makeinindia.png" alt="Make in India website link"/></a></li>
        <li><a target="_blank"  rel="noreferrer" href="http://goidirectory.nic.in/" title="GOI Web Directory, External Link that opens in a new window"><img src="assets/images/carousel/goidirectory.png" alt="GOI Directory website link"/></a></li>
        <li><a target="_blank"  rel="noreferrer" href="https://mygov.in/" title="MyGov, External Link that opens in a new window"><img src="assets/images/carousel/mygov.png" alt="MyGov website link"/></a></li>
        <li><a target="_blank"  rel="noreferrer" href="https://eci.gov.in/" title="Election Commission of India, External Link that opens in a new window"><img src="assets/images/carousel/eci.png" alt="Election Commission of India website link"/></a></li>
        <li><a target="_blank"  rel="noreferrer" href="http://egazette.nic.in/" title="eGazette, External Link that opens in a new window"><img src="assets/images/carousel/e-gazette.png" alt="eGazette website link"/></a></li>
        <li><a target="_blank"  rel="noreferrer" href="https://evisitors.nic.in" title="MyVisit, External Link that opens in a new window"><img src="assets/images/carousel/myvisit-logo.png" alt="eVisitors website link"/></a></li>
        <li><a target="_blank"  rel="noreferrer" href="https://pgportal.gov.in/" title="Centralized Public Grievance Redress and Monitoring System, External Link that opens in a new window"><img src="assets/images/carousel/pg-portal.png" alt="PG Portal website link"/></a></li>
      </ul>
    </div>
  </div>
</div>
  </div>
     );
}

export default SubFooter;
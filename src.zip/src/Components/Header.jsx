import React from 'react';

function Header() {
    return ( <>
    <div>
        <section className="flex"> 
      <div className="container header-container">
          <h1 className="logo">
              <a href="home.html" title="Home" rel="home" className="header__logo" id="logo">
                 <img className="national_emblem" src="./assets/images/emblem-dark.png" alt="logo"/>
                 <strong style={{fontsize: "107%"}}>सामान्य प्रशासन</strong>
                <span>GENERAL ADMINISTRATION DEPARTMENT</span>
              </a>
            </h1>
    </div>
  </section>
  </div>
        </>
     );
}

export default Header;
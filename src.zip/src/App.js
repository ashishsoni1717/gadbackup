//import logo from './logo.svg';
import './App.css';
import Header from './Components/Header';
import Navbar from './Components/Header';
import Notice from './Components/Notice';
import Footer from './Components/Footer';
import SubFooter from './Components/SubFooter';


function App() {
  return (
    <>
    <Header/>
    <Navbar/>
    <Notice/>
    <SubFooter/>
    <Footer/>
    
    </>
  );
}

export default App;
